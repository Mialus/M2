package projetAD;

public enum MsgType {
    TOKEN, REQ, YES, START, LEADER, IMLEADER;
}
